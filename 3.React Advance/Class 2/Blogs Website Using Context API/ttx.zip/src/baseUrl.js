export const baseUrl = "https://codehelp-apis.vercel.app/api/get-blogs";
